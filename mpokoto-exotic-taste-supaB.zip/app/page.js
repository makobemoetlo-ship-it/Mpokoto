
'use client'
import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

const DEFAULT_BRANCHES=[
  {id:'limpopo', name:'Limpopo Gamasemola', gps:'-24.4500,29.5000', address:'Gamasemola Village, Limpopo', pin:'Request pin via WhatsApp'},
  {id:'mpumalanga', name:'Mpumalanga Seabe', gps:'-25.2000,29.1000', address:'Seabe, Mpumalanga', pin:'Request pin via WhatsApp'},
  {id:'gauteng', name:'Gauteng Boksburg', gps:'-26.2100,28.2590', address:'Boksburg, Gauteng', pin:'Request pin via WhatsApp'},
]

const DEFAULT_PRODUCTS=[
  {id:'1', name:'Mango Atchaar Hot', category:'Atchaar', description:'Authentic homemade mango atchaar, extra hot', image:'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600', sizes:[{size:'250ml', price:45},{size:'500ml', price:85},{size:'1L', price:150}], stock:100},
  {id:'2', name:'Mixed Veg Atchaar', category:'Atchaar', description:'Crunchy mixed veg atchaar', image:'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600', sizes:[{size:'250ml', price:40},{size:'500ml', price:75},{size:'750ml', price:110}], stock:100},
  {id:'3', name:'Chilli Atchaar', category:'Atchaar', description:'Fiery chilli atchaar', image:'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=600', sizes:[{size:'200ml', price:35},{size:'400ml', price:65},{size:'800ml', price:120}], stock:100},
]

export default function Page(){
  const [products, setProducts] = useState(DEFAULT_PRODUCTS)
  const [settings, setSettings] = useState({whatsapp_number:'0764721066', fnb_account:'FNB 63136139458', branches:DEFAULT_BRANCHES})
  const [cart, setCart] = useState([])
  const [branch, setBranch] = useState(DEFAULT_BRANCHES[0])
  const [view, setView] = useState('shop') // shop, cart, admin, orders
  const [adminAuth, setAdminAuth] = useState(false)
  const [adminPass, setAdminPass] = useState('')
  const [orders, setOrders] = useState([])
  const [editingProduct, setEditingProduct] = useState(null)
  const [customer, setCustomer] = useState({name:'', phone:'', address:'', payment:'Cash in store when collecting', proof:''})
  const [live, setLive] = useState(false)

  // LIVE LOAD
  useEffect(()=>{
    const load = async ()=>{
      if(supabase){
        const {data:p} = await supabase.from('products').select('*')
        if(p && p.length) setProducts(p)
        const {data:s} = await supabase.from('settings').select('*').single()
        if(s){ setSettings({whatsapp_number:s.whatsapp_number, fnb_account:s.fnb_account, branches:s.branches || DEFAULT_BRANCHES}) ; setBranch(s.branches?.[0] || DEFAULT_BRANCHES[0]) }
        const {data:o} = await supabase.from('orders').select('*').order('created_at',{ascending:false})
        if(o) setOrders(o)
        setLive(true)
      } else {
        const local = localStorage.getItem('mpokoto_products_live')
        if(local) setProducts(JSON.parse(local))
        const localSet = localStorage.getItem('mpokoto_settings_live')
        if(localSet) { const parsed=JSON.parse(localSet); setSettings(parsed); setBranch(parsed.branches?.[0]) }
        const localOrders = localStorage.getItem('mpokoto_orders_live')
        if(localOrders) setOrders(JSON.parse(localOrders))
        setLive(true)
      }
    }
    load()
    const savedCart = localStorage.getItem('mpokoto_cart')
    if(savedCart) setCart(JSON.parse(savedCart))
  },[])

  useEffect(()=>{ localStorage.setItem('mpokoto_cart', JSON.stringify(cart)) },[cart])
  useEffect(()=>{
    if(!supabase){ localStorage.setItem('mpokoto_products_live', JSON.stringify(products)) }
  },[products])
  useEffect(()=>{
    if(!supabase){ localStorage.setItem('mpokoto_settings_live', JSON.stringify(settings)) }
  },[settings])

  const saveProduct = async (prod)=>{
    let updated
    if(products.find(p=>p.id===prod.id)){ updated = products.map(p=>p.id===prod.id?prod:p) }
    else { updated=[...products, {...prod, id: prod.id || Date.now().toString()}] }
    setProducts(updated)
    if(supabase){
      if(prod.id && prod.id.length>10) await supabase.from('products').upsert(prod)
      else { const {id,...rest}=prod; await supabase.from('products').insert(rest) }
    }
    setEditingProduct(null)
  }
  const deleteProduct = async (id)=>{
    setProducts(products.filter(p=>p.id!==id))
    if(supabase) await supabase.from('products').delete().eq('id',id)
  }

  const addToCart = (product, sizeObj)=>{
    setCart([...cart, {productId:product.id, name:product.name, size:sizeObj.size, price:sizeObj.price, image:product.image, qty:1, branch:branch.name}])
  }

  const cartTotal = cart.reduce((s,i)=>s + i.price*i.qty,0)

  const placeOrder = async ()=>{
    if(!customer.name || !customer.phone) { alert('Enter name and phone'); return }
    if(cart.length===0){ alert('Cart empty'); return }
    const order = {
      id: Date.now().toString(),
      customer_name: customer.name,
      customer_phone: customer.phone,
      customer_address: customer.address,
      branch_id: branch.id,
      branch_name: branch.name,
      items: cart,
      total: cartTotal,
      payment_method: customer.payment,
      payment_proof_url: customer.proof || '',
      status:'new',
      created_at: new Date().toISOString()
    }
    const newOrders=[order, ...orders]
    setOrders(newOrders)
    if(supabase){
      await supabase.from('orders').insert({customer_name:order.customer_name, customer_phone:order.customer_phone, customer_address:order.customer_address, branch_id:order.branch_id, branch_name:order.branch_name, items:order.items, total:order.total, payment_method:order.payment_method, payment_proof_url:order.payment_proof_url})
    } else {
      localStorage.setItem('mpokoto_orders_live', JSON.stringify(newOrders))
    }
    // WhatsApp
    const text = `*NEW ORDER - Mpokoto Exotic Taste*%0A%0A*Customer:* ${customer.name}%0A*Phone:* ${customer.phone}%0A*Address:* ${customer.address}%0A*Branch:* ${branch.name}%0A*GPS:* https://maps.google.com/?q=${branch.gps}%0A%0A*Items:*%0A${cart.map(i=>`- ${i.name} (${i.size}) x${i.qty} = R${i.price*i.qty}`).join('%0A')}%0A%0A*Total:* R${cartTotal}%0A*Payment:* ${customer.payment}%0A${customer.payment.includes('Online')?`*FNB:* ${settings.fnb_account}%0A*Proof:* ${customer.proof}%0A`:''}%0A%0APin request: Customer may ask for GPS pin to store.`
    const waNumber = settings.whatsapp_number.replace(/[^0-9]/g,'')
    window.open(`https://wa.me/${waNumber}?text=${text}`, '_blank')
    alert('Order placed! Slip generated. Check admin orders.')
    setCart([])
    setView('shop')
  }

  const downloadDailySales = ()=>{
    const today = new Date().toDateString()
    const todays = orders.filter(o=> new Date(o.created_at).toDateString()===today)
    const csv = ['Date,Customer,Phone,Branch,Items,Total,Payment,Status'].concat(todays.map(o=>`"${o.created_at}","${o.customer_name}","${o.customer_phone}","${o.branch_name}","${o.items.map(i=>i.name+' '+i.size+' x'+i.qty).join('; ')}",${o.total},${o.payment_method},${o.status}`)).join('\n')
    const blob = new Blob([csv], {type:'text/csv'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href=url; a.download=`mpokoto-sales-${new Date().toISOString().slice(0,10)}.csv`; a.click()
  }

  const cashUp = ()=>{
    const today = new Date().toDateString()
    const todays = orders.filter(o=> new Date(o.created_at).toDateString()===today)
    const total = todays.reduce((s,o)=>s+Number(o.total),0)
    const cash = todays.filter(o=>o.payment_method.includes('Cash')).reduce((s,o)=>s+Number(o.total),0)
    const card = todays.filter(o=>o.payment_method.includes('Card')).reduce((s,o)=>s+Number(o.total),0)
    const online = todays.filter(o=>o.payment_method.includes('Online')).reduce((s,o)=>s+Number(o.total),0)
    alert(`CASH UP - ${today}\nTotal Orders: ${todays.length}\nGrand Total: R${total}\nCash: R${cash}\nCard: R${card}\nOnline: R${online}`)
  }

  if(view==='admin' && !adminAuth){
    return (
      <div style={{minHeight:'100vh', display:'grid', placeItems:'center', background:'#FFFBF5'}}>
        <div className="card" style={{padding:32, width:360}}>
          <h2>Admin Login - LIVE</h2>
          <p style={{fontSize:12, margin:'8px 0'}}>Password: admin123 (change in settings)</p>
          <input value={adminPass} onChange={e=>setAdminPass(e.target.value)} placeholder="Password" type="password" style={{width:'100%', padding:12, margin:'12px 0', borderRadius:8, border:'1px solid #ddd'}} />
          <button className="btn" style={{width:'100%'}} onClick={()=>{ if(adminPass==='admin123' || adminPass==='Mpokoto2024'){ setAdminAuth(true) } else alert('Wrong password') }}>Login</button>
          <button onClick={()=>setView('shop')} style={{marginTop:12, background:'none', border:'none', cursor:'pointer'}}>← Back to shop</button>
        </div>
      </div>
    )
  }

  return (
    <div style={{minHeight:'100vh'}}>
      <header style={{position:'sticky', top:0, zIndex:50, background:'rgba(255,251,245,0.9)', backdropFilter:'blur(12px)', borderBottom:'1px solid #F5E6D3', padding:'12px 24px', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div style={{display:'flex', alignItems:'center', gap:12}}>
          <div style={{width:40,height:40, background:'#4A1C1C', borderRadius:12, display:'grid', placeItems:'center', color:'#D4A017', fontWeight:900}}>M</div>
          <div><div style={{fontWeight:900, color:'#4A1C1C'}}>Mpokoto Exotic Taste</div><div style={{fontSize:11, display:'flex', gap:6, alignItems:'center'}}><span className="live-dot"></span> {live?'LIVE • Real-time sync • Rands':'Connecting...'} </div></div>
        </div>
        <div style={{display:'flex', gap:8}}>
          <button className="btn" onClick={()=>setView('shop')}>Shop</button>
          <button className="btn" style={{background:'white', color:'#4A1C1C', border:'1px solid #ddd'}} onClick={()=>setView('cart')}>Cart ({cart.length}) R{cartTotal}</button>
          <button className="btn btn-gold" onClick={()=>setView('admin')}>Admin Orders ({orders.length})</button>
        </div>
      </header>

      {view==='shop' && (
        <div style={{maxWidth:1200, margin:'0 auto', padding:24}}>
          <div className="card" style={{padding:20, marginBottom:20, display:'flex', flexWrap:'wrap', gap:16, justifyContent:'space-between', alignItems:'center'}}>
            <div>
              <h3>Collect From:</h3>
              <div style={{display:'flex', gap:8, marginTop:8, flexWrap:'wrap'}}>
                {settings.branches.map(b=>(
                  <button key={b.id} onClick={()=>setBranch(b)} style={{padding:'8px 14px', borderRadius:20, border: branch.id===b.id?'2px solid #4A1C1C':'1px solid #ddd', background: branch.id===b.id?'#4A1C1C':'white', color: branch.id===b.id?'white':'#4A1C1C', cursor:'pointer', fontWeight:700}}>{b.name}</button>
                ))}
              </div>
              <div style={{fontSize:12, marginTop:8}}>📍 {branch.address} • <a href={`https://maps.google.com/?q=${branch.gps}`} target="_blank">Get GPS Pin</a> • {branch.pin}</div>
            </div>
            <div style={{fontSize:12, background:'#FFF2E2', padding:12, borderRadius:12}}>
              <b>WhatsApp Orders:</b> {settings.whatsapp_number}<br/>
              <b>FNB:</b> {settings.fnb_account}<br/>
              Payment: Cash / Card in-store / Online with proof
            </div>
          </div>

          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:20}}>
            {products.map(p=>(
              <div key={p.id} className="card" style={{overflow:'hidden'}}>
                <img src={p.image} style={{width:'100%', height:180, objectFit:'cover'}} />
                <div style={{padding:16}}>
                  <div style={{fontWeight:900, color:'#4A1C1C'}}>{p.name}</div>
                  <div style={{fontSize:12, color:'#666', margin:'6px 0'}}>{p.description}</div>
                  <div style={{marginTop:10}}>
                    {p.sizes.map(s=>(
                      <div key={s.size} style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 0', borderBottom:'1px dashed #F5E6D3'}}>
                        <span style={{fontSize:14}}>{s.size}</span>
                        <span style={{display:'flex', gap:8, alignItems:'center'}}><b style={{color:'#4A1C1C'}}>R {s.price}</b><button className="btn" style={{padding:'6px 12px', fontSize:12}} onClick={()=>addToCart(p,s)}>Add</button></span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {view==='cart' && (
        <div style={{maxWidth:800, margin:'0 auto', padding:24}}>
          <h2>Your Order - Collect at {branch.name}</h2>
          <div className="card" style={{padding:16, marginTop:16}}>
            {cart.length===0 && <div>Cart empty</div>}
            {cart.map((c,i)=>(
              <div key={i} style={{display:'flex', justifyContent:'space-between', padding:'12px 0', borderBottom:'1px solid #eee'}}>
                <div><img src={c.image} style={{width:50,height:50, objectFit:'cover', borderRadius:8, verticalAlign:'middle', marginRight:8}} />{c.name} ({c.size})</div>
                <div>R{c.price} x {c.qty} <button onClick={()=>setCart(cart.filter((_,idx)=>idx!==i))} style={{marginLeft:8}}>Remove</button></div>
              </div>
            ))}
            <div style={{textAlign:'right', fontWeight:900, marginTop:12}}>Total: R {cartTotal}</div>
          </div>

          <div className="card" style={{padding:16, marginTop:16}}>
            <h3>Customer Slip Details (will show on slip)</h3>
            <input placeholder="Full Name" value={customer.name} onChange={e=>setCustomer({...customer, name:e.target.value})} style={{width:'100%', padding:12, margin:'8px 0', borderRadius:8, border:'1px solid #ddd'}} />
            <input placeholder="Phone / WhatsApp" value={customer.phone} onChange={e=>setCustomer({...customer, phone:e.target.value})} style={{width:'100%', padding:12, margin:'8px 0', borderRadius:8, border:'1px solid #ddd'}} />
            <input placeholder="Address (optional if collecting)" value={customer.address} onChange={e=>setCustomer({...customer, address:e.target.value})} style={{width:'100%', padding:12, margin:'8px 0', borderRadius:8, border:'1px solid #ddd'}} />
            <select value={branch.id} onChange={e=>{ const b=settings.branches.find(x=>x.id===e.target.value); setBranch(b) }} style={{width:'100%', padding:12, margin:'8px 0', borderRadius:8}}>
              {settings.branches.map(b=><option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
            <label style={{display:'block', margin:'12px 0 6px', fontWeight:700}}>Payment Method</label>
            <select value={customer.payment} onChange={e=>setCustomer({...customer, payment:e.target.value})} style={{width:'100%', padding:12, borderRadius:8}}>
              <option>Cash in store when collecting orders</option>
              <option>Card payment in store when collecting orders</option>
              <option>Online payment with proof of payment attached</option>
            </select>
            {customer.payment.includes('Online') && (
              <div style={{marginTop:12, background:'#FFF2E2', padding:12, borderRadius:12}}>
                <div>Pay to: <b>{settings.fnb_account}</b> (FNB 63136139458)</div>
                <input placeholder="Paste proof of payment link / reference" value={customer.proof} onChange={e=>setCustomer({...customer, proof:e.target.value})} style={{width:'100%', padding:12, marginTop:8, borderRadius:8, border:'1px solid #ddd'}} />
                <div style={{fontSize:11, marginTop:6}}>Upload proof to Imgur/Drive and paste link, or type EFT reference</div>
              </div>
            )}
            <div style={{marginTop:16, display:'flex', gap:8}}>
              <button className="btn" style={{flex:1}} onClick={placeOrder}>Place Order - Generate Slip + WhatsApp {settings.whatsapp_number}</button>
            </div>
            <div style={{fontSize:11, marginTop:8}}>📌 Customer can ask for GPS pin: <a href={`https://maps.google.com/?q=${branch.gps}`} target="_blank">Open GPS for {branch.name}</a></div>
          </div>
        </div>
      )}

      {view==='admin' && (
        <div style={{maxWidth:1200, margin:'0 auto', padding:24}}>
          <div style={{display:'flex', gap:8, flexWrap:'wrap', marginBottom:16}}>
            <button className="btn btn-gold" onClick={downloadDailySales}>⬇ Download Daily Sales CSV</button>
            <button className="btn" onClick={cashUp}>💰 Cash Up (Today)</button>
            <button className="btn" style={{background:'white', color:'#4A1C1C', border:'1px solid #ddd'}} onClick={()=>window.print()}>🖨 Print Orders</button>
          </div>

          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:20}}>
            <div className="card" style={{padding:16}}>
              <h3>Store Settings - LIVE</h3>
              <label>WhatsApp Number (editable)</label>
              <input value={settings.whatsapp_number} onChange={e=>{ const s={...settings, whatsapp_number:e.target.value}; setSettings(s); if(supabase) supabase.from('settings').update({whatsapp_number:e.target.value}).eq('id',1).then(()=>{}) }} style={{width:'100%', padding:10, margin:'6px 0 12px', borderRadius:8, border:'1px solid #ddd'}} />
              <label>FNB Account (editable)</label>
              <input value={settings.fnb_account} onChange={e=>{ const s={...settings, fnb_account:e.target.value}; setSettings(s); if(supabase) supabase.from('settings').update({fnb_account:e.target.value}).eq('id',1).then(()=>{}) }} style={{width:'100%', padding:10, margin:'6px 0 12px', borderRadius:8, border:'1px solid #ddd'}} />
              <h4>Branches (editable)</h4>
              {settings.branches.map((b,i)=>(
                <div key={b.id} style={{border:'1px solid #eee', padding:10, borderRadius:8, margin:'8px 0'}}>
                  <input value={b.name} onChange={e=>{ const nb=[...settings.branches]; nb[i].name=e.target.value; setSettings({...settings, branches:nb}) }} style={{width:'100%', padding:8, marginBottom:4}} />
                  <input value={b.gps} onChange={e=>{ const nb=[...settings.branches]; nb[i].gps=e.target.value; setSettings({...settings, branches:nb}) }} style={{width:'100%', padding:8, marginBottom:4}} placeholder="GPS" />
                  <input value={b.address} onChange={e=>{ const nb=[...settings.branches]; nb[i].address=e.target.value; setSettings({...settings, branches:nb}) }} style={{width:'100%', padding:8}} placeholder="Address" />
                </div>
              ))}
              <button className="btn" onClick={async()=>{ if(supabase) await supabase.from('settings').update({branches:settings.branches, whatsapp_number:settings.whatsapp_number, fnb_account:settings.fnb_account}).eq('id',1); alert('Settings saved LIVE') }}>Save Settings Live</button>
            </div>

            <div className="card" style={{padding:16}}>
              <h3>Products - Prices in Rands next to sizes</h3>
              <button className="btn" onClick={()=>setEditingProduct({name:'', description:'', image:'', sizes:[{size:'250ml', price:45}], category:'Atchaar'})}>+ Add Atchaar</button>
              <div style={{marginTop:12, maxHeight:500, overflow:'auto'}}>
                {products.map(p=>(
                  <div key={p.id} style={{display:'flex', gap:8, padding:8, borderBottom:'1px solid #eee', alignItems:'center'}}>
                    <img src={p.image} style={{width:40,height:40, objectFit:'cover', borderRadius:6}} />
                    <div style={{flex:1}}><b>{p.name}</b><div style={{fontSize:11}}>{p.sizes.map(s=>`${s.size}: R${s.price}`).join(' | ')}</div></div>
                    <button onClick={()=>setEditingProduct(p)} style={{padding:'6px 10px'}}>Edit</button>
                    <button onClick={()=>deleteProduct(p.id)} style={{padding:'6px 10px', background:'#ff4444', color:'white', border:'none', borderRadius:6}}>Delete</button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {editingProduct && (
            <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,0.5)', display:'grid', placeItems:'center', zIndex:100}}>
              <div className="card" style={{padding:20, width:'95%', maxWidth:500, maxHeight:'90vh', overflow:'auto'}}>
                <h3>Edit Atchaar - Image Editable + Sizes & Prices in Rands</h3>
                <input placeholder="Name" value={editingProduct.name} onChange={e=>setEditingProduct({...editingProduct, name:e.target.value})} style={{width:'100%', padding:10, margin:'8px 0', borderRadius:8, border:'1px solid #ddd'}} />
                <textarea placeholder="Description" value={editingProduct.description} onChange={e=>setEditingProduct({...editingProduct, description:e.target.value})} style={{width:'100%', padding:10, margin:'8px 0', borderRadius:8, border:'1px solid #ddd'}} />
                <label>Image - Paste URL or Upload</label>
                <input placeholder="Image URL" value={editingProduct.image} onChange={e=>setEditingProduct({...editingProduct, image:e.target.value})} style={{width:'100%', padding:10, margin:'6px 0', borderRadius:8, border:'1px solid #ddd'}} />
                <input type="file" accept="image/*" onChange={e=>{ const file=e.target.files[0]; if(file){ const r=new FileReader(); r.onload=()=>setEditingProduct({...editingProduct, image:r.result}); r.readAsDataURL(file) } }} style={{marginBottom:8}} />
                {editingProduct.image && <img src={editingProduct.image} style={{width:'100%', height:150, objectFit:'cover', borderRadius:8, marginBottom:8}} />}
                <h4>Sizes + Prices in Rands (next to each size)</h4>
                {editingProduct.sizes.map((s, idx)=>(
                  <div key={idx} style={{display:'flex', gap:6, marginBottom:6}}>
                    <input value={s.size} onChange={e=>{ const ns=[...editingProduct.sizes]; ns[idx].size=e.target.value; setEditingProduct({...editingProduct, sizes:ns}) }} placeholder="Size e.g. 500ml" style={{flex:1, padding:8, borderRadius:6, border:'1px solid #ddd'}} />
                    <span style={{padding:'8px 4px'}}>R</span>
                    <input type="number" value={s.price} onChange={e=>{ const ns=[...editingProduct.sizes]; ns[idx].price=Number(e.target.value); setEditingProduct({...editingProduct, sizes:ns}) }} placeholder="Price" style={{width:100, padding:8, borderRadius:6, border:'1px solid #ddd'}} />
                    <button onClick={()=>{ const ns=editingProduct.sizes.filter((_,i)=>i!==idx); setEditingProduct({...editingProduct, sizes:ns}) }}>X</button>
                  </div>
                ))}
                <button onClick={()=>setEditingProduct({...editingProduct, sizes:[...editingProduct.sizes, {size:'', price:0}]})} style={{marginBottom:12}}> + Add Size</button>
                <div style={{display:'flex', gap:8}}>
                  <button className="btn" style={{flex:1}} onClick={()=>saveProduct(editingProduct)}>Save LIVE - Updates instantly for all shoppers</button>
                  <button onClick={()=>setEditingProduct(null)} style={{padding:'10px 16px'}}>Cancel</button>
                </div>
              </div>
            </div>
          )}

          <div className="card" style={{padding:16, marginTop:20}}>
            <h3>Orders - Slip with Customer Details, Branch, Payment (Printable)</h3>
            {orders.length===0 && <div>No orders yet</div>}
            {orders.map(o=>(
              <div key={o.id} className="card" style={{padding:12, margin:'12px 0', border:'2px solid #4A1C1C'}}>
                <div style={{display:'flex', justifyContent:'space-between'}}>
                  <b>Order Slip #{o.id.slice(0,8)}</b><span>{new Date(o.created_at).toLocaleString()}</span>
                </div>
                <div style={{fontSize:13, marginTop:8, background:'#FFFBF5', padding:10, borderRadius:8}}>
                  <b>Customer:</b> {o.customer_name} | <b>Phone:</b> {o.customer_phone}<br/>
                  <b>Address:</b> {o.customer_address || 'N/A - Collect in store'}<br/>
                  <b>Branch Collection:</b> {o.branch_name} ({o.branch_id}) - <a href={`https://maps.google.com/?q=${settings.branches.find(b=>b.id===o.branch_id)?.gps}`} target="_blank">GPS Pin</a><br/>
                  <b>Items:</b> {o.items.map(i=>`${i.name} (${i.size}) x${i.qty} = R${i.price*i.qty}`).join(', ')}<br/>
                  <b>Total:</b> R {o.total} | <b>Payment:</b> {o.payment_method} | <b>FNB:</b> {settings.fnb_account}<br/>
                  {o.payment_proof_url && <><b>Proof:</b> {o.payment_proof_url}<br/></>}
                </div>
                <div style={{marginTop:8, display:'flex', gap:8}}>
                  <button onClick={()=>{ const text=`Your order ${o.id.slice(0,8)} is ready for collection at ${o.branch_name}. Total R${o.total}. GPS: https://maps.google.com/?q=${settings.branches.find(b=>b.id===o.branch_id)?.gps}`; window.open(`https://wa.me/${o.customer_phone.replace(/[^0-9]/g,'')}?text=${encodeURIComponent(text)}`) }}>WhatsApp Customer</button>
                  <button onClick={()=>window.print()}>Print Slip</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
