
-- MPOKOTO EXOTIC TASTE - LIVE SCHEMA
-- Run this in Supabase SQL Editor

create table products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text default 'Atchaar',
  description text,
  image text,
  sizes jsonb default '[{"size":"250ml","price":45},{"size":"500ml","price":80},{"size":"750ml","price":120}]'::jsonb,
  stock int default 100,
  created_at timestamp default now()
);

create table settings (
  id int primary key default 1,
  whatsapp_number text default '0764721066',
  fnb_account text default 'FNB 63136139458',
  branches jsonb default '[{"id":"limpopo","name":"Limpopo Gamasemola","gps":"-24.4500,29.5000","pin":"Ask admin for pin"},{"id":"mpumalanga","name":"Mpumalanga Seabe","gps":"-25.2000,29.1000","pin":"Ask admin for pin"},{"id":"gauteng","name":"Gauteng Boksburg","gps":"-26.2100,28.2590","pin":"Ask admin for pin"}]'::jsonb
);

create table orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  customer_phone text not null,
  customer_address text,
  branch_id text not null,
  branch_name text,
  items jsonb not null,
  total numeric not null,
  payment_method text not null,
  payment_proof_url text,
  status text default 'new',
  created_at timestamp default now()
);

-- enable RLS for live
alter table products enable row level security;
alter table settings enable row level security;
alter table orders enable row level security;

create policy "public read" on products for select using (true);
create policy "admin all" on products for all using (true);
create policy "public read settings" on settings for select using (true);
create policy "admin all settings" on settings for all using (true);
create policy "public insert orders" on orders for insert with check (true);
create policy "admin read orders" on orders for select using (true);
create policy "admin update orders" on orders for update using (true);

-- seed settings
insert into settings (id) values (1) on conflict (id) do nothing;

-- seed atchaar products
insert into products (name, category, description, image, sizes) values
('Mango Atchaar Hot', 'Atchaar', 'Authentic homemade mango atchaar, extra hot and flavorful', 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600', '[{"size":"250ml","price":45},{"size":"500ml","price":85},{"size":"1L","price":150}]'),
('Mixed Veg Atchaar', 'Atchaar', 'Crunchy mixed vegetable atchaar with secret spices', 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600', '[{"size":"250ml","price":40},{"size":"500ml","price":75},{"size":"750ml","price":110}]'),
('Chilli Atchaar', 'Atchaar', 'Fiery chilli atchaar for real heat lovers', 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=600', '[{"size":"200ml","price":35},{"size":"400ml","price":65},{"size":"800ml","price":120}]');
