
# Mpokoto Exotic Taste - LIVE APP

## Fix for previous demo issue
Old vercel app was static with hardcoded prices. This is LIVE with Supabase.

## Setup to keep LIVE and smooth at all times
1. npm install
2. Create Supabase project, run supabase/schema.sql
3. Copy .env.example to .env.local and add URL + anon key
4. npm run dev - test locally
5. Deploy to Vercel: vercel --prod
6. In Vercel env vars, add NEXT_PUBLIC_SUPABASE_URL and KEY
7. Enable Supabase Realtime for instant sync

## Features implemented
- Atchaar sizes + prices in Rands next to each size, editable by admin
- Images editable (URL + upload)
- WhatsApp 0764721066 editable in admin settings
- Order slip with customer name, contacts, address, branch
- Payment: Cash in store, Card in store, Online with proof -> FNB 63136139458
- Branches: Limpopo Gamasemola, Mpumalanga Seabe, Gauteng Boksburg + GPS pin
- Daily sales download CSV, Print, Cash Up

Admin: /admin -> password admin123 (change in code)
Orders auto WhatsApp to admin number + customer.

For always LIVE: Don't use localStorage fallback, ensure supabase env set. Add Vercel Analytics.
