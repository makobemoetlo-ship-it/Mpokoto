
import './globals.css'
export const metadata={title:'Mpokoto Exotic Taste - LIVE', description:'Live atchaar store - prices in Rands'}
export default function RootLayout({children}){return (<html lang="en"><body>{children}</body></html>)}
